let word1 = "Arizona";
let word2 = "Leadership";
let word3 = "Python";
let word4 = "Bellevue";

function changeWord(wordLoc, word) {
    document.getElementById(wordLoc).innerHTML = word;
}